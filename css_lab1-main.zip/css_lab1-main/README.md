
- Yêu cầu sử dụng các thuộc tính css: để hoàn thiện bài trong ảnh [Ảnh](https://huyhaq.github.io/css_lab1/27.png)
- Sử dụng file index html có sẵn, chỉnh sửa trong file style.css
